package Mobile_Shop.Mobile_shop_Management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileShopManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
