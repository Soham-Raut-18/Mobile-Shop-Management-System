package Mobile_Shop.Mobile_shop_Management_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobileShopManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobileShopManagementSystemApplication.class, args);
	}

}
