package Mobile_Shop.Mobile_shop_Management_system;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class customer_management {
	
	 @Id
	 int c_id;
	 String customer_name;
	 long mob_no;
	 int mob_id;
	 
	 public customer_management() {
		super();
		// TODO Auto-generated constructor stub
	}
	public customer_management(int c_id, String customer_name, long mob_no, int mob_id) {
		super();
		this.c_id = c_id;
		this.customer_name = customer_name;
		this.mob_no = mob_no;
		this.mob_id = mob_id;
	}
	public int getC_id() {
		return c_id;
	}
	public void setC_id(int c_id) {
		this.c_id = c_id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public long getMob_no() {
		return mob_no;
	}
	public void setMob_no(long mob_no) {
		this.mob_no = mob_no;
	}
	public int getMob_id() {
		return mob_id;
	}
	public void setMob_id(int mob_id) {
		this.mob_id = mob_id;
	}
	 

}
