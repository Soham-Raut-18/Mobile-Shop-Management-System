package Mobile_Shop.Mobile_shop_Management_system;

import java.util.List;
import java.util.Locale.Category;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class mobileController {
	
	@Autowired
	SessionFactory fact;
	
	
	
	@GetMapping("getmobiledata")
	public List<Object> getdata() {

		Session session = fact.openSession();
		NativeQuery<Object> query=session.createSQLQuery("select *from mobile");

		List<Object> list = query.list(); 

		return list;
	}
	@GetMapping("getalldata")
	public List getalldata() {
		Session session=fact.openSession();
		Criteria cr=session.createCriteria(mobile.class);
		List<mobile> list=cr.list();
		return list;
		
	}

	@PostMapping("addMobile")
	public String addmobile (@RequestBody  mobile mob) {
		Session session=fact.openSession();
		Transaction tr=session.beginTransaction();
		
		session.saveOrUpdate(mob);
		tr.commit();
		
	
	
		return "mobile added";
		
	}
	
	@DeleteMapping("deleteMobile/{id}")
	public  String deletedata(@PathVariable int id) {
		
		Session session=fact.openSession();
		Transaction tr=session.beginTransaction();
		mobile obj=session.load(mobile.class, id);
		session.delete(obj);
		tr.commit();
		return "mobile Data Deleted";
	}
	@PutMapping("updateMobile")
	public String updateCustomer (@RequestBody  mobile mob) {
		Session session=fact.openSession();
		Transaction tr=session.beginTransaction();
		
		session.update(mob);
		tr.commit();
		return "Mobile updated";
}
	
}
